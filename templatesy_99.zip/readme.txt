More templates here:
 
http://www.templatesy.com