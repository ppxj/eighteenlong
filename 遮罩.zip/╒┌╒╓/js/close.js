	var mask=document.getElementById("mask");
		mask.onclick=function () {
		document.getElementById("back").style.display="block";
		document.getElementById("block").style.display="block";
	}
	document.getElementById("close").onclick=function () {
		document.getElementById("back").style.display="none";
		document.getElementById("block").style.display="none";
	};